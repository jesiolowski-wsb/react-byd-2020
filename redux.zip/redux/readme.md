# Welcome to Redux!

Here's a description of the source code included in this course. 


# Folders

- **redux-starter**: The starter project for this course.
- **redux-finish**: The completed Redux project (without React). It contains all the code
- **bugs-backend**: A basic Node.js back-end for the bug tracker app. You'll use it in the section titled Calling APIs.
- **bugs-frontend**: The completed React/Redux front-end for the bug tracker app.

